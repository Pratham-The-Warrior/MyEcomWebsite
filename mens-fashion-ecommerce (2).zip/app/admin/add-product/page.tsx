import { redirect } from "next/navigation"
import { isAuthenticated } from "@/lib/auth"
import AddProductForm from "@/components/add-product-form"

export default async function AddProductPage() {
  const isAdmin = await isAuthenticated()

  if (!isAdmin) {
    redirect("/admin/login")
  }

  return <AddProductForm />
}
