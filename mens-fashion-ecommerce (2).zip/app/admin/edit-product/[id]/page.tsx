import { redirect } from "next/navigation"
import { isAuthenticated } from "@/lib/auth"
import { getProductById } from "@/lib/db-service"
import EditProductForm from "@/components/edit-product-form"

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const isAdmin = await isAuthenticated()

  if (!isAdmin) {
    redirect("/admin/login")
  }

  const product = await getProductById(params.id)

  if (!product) {
    redirect("/admin")
  }

  return <EditProductForm product={product} />
}
