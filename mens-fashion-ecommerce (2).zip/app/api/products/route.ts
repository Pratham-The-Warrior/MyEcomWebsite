import { type NextRequest, NextResponse } from "next/server"
import { getAllProducts, addProduct } from "@/lib/db-service"
import { isAuthenticated } from "@/lib/auth"

export async function GET() {
  try {
    const products = await getAllProducts()
    return NextResponse.json(products)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  const isAdmin = await isAuthenticated()
  if (!isAdmin) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const productData = await request.json()
    const result = await addProduct(productData)

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 400 })
    }

    return NextResponse.json(result.product, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to add product" }, { status: 500 })
  }
}
