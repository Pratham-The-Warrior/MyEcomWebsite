"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Minus, Plus, ShoppingBag, Trash2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { useCart } from "@/lib/cart-context"

export default function CartPage() {
  const { cartItems, updateCartItemQuantity, removeFromCart, clearCart } = useCart()
  const [promoCode, setPromoCode] = useState("")
  const [isApplyingPromo, setIsApplyingPromo] = useState(false)

  const subtotal = cartItems.reduce((total, item) => total + item.price * (item.quantity || 1), 0)
  const shipping = subtotal > 100 ? 0 : 10
  const total = subtotal + shipping

  const handleApplyPromo = () => {
    setIsApplyingPromo(true)
    // Simulate API call
    setTimeout(() => {
      setIsApplyingPromo(false)
      setPromoCode("")
      // Add promo code logic here
    }, 1000)
  }

  const handleCheckout = () => {
    // Implement checkout logic
    alert("Checkout functionality would be implemented here")
  }

  if (cartItems.length === 0) {
    return (
      <div className="container px-4 py-12 md:px-6 md:py-16 lg:py-24">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <ShoppingBag className="h-16 w-16 text-zinc-300" />
          <h1 className="text-3xl font-bold">Your cart is empty</h1>
          <p className="text-zinc-500">Looks like you haven't added anything to your cart yet.</p>
          <Link href="/products">
            <Button size="lg" className="mt-4">
              Continue Shopping
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="container px-4 py-12 md:px-6 md:py-16 lg:py-24">
      <div className="flex flex-col gap-8 lg:flex-row lg:gap-12">
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold">Shopping Cart</h1>
            <Button variant="ghost" size="sm" onClick={clearCart} className="text-zinc-500">
              Clear Cart
            </Button>
          </div>
          <div className="mt-8 space-y-6">
            {cartItems.map((item) => (
              <div key={item.id} className="flex gap-4 py-4">
                <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border">
                  <img src={item.image || "/placeholder.svg"} alt={item.name} className="h-full w-full object-cover" />
                </div>
                <div className="flex flex-1 flex-col">
                  <div className="flex justify-between text-base font-medium">
                    <h3>
                      <Link href={`/products/${item.id}`}>{item.name}</Link>
                    </h3>
                    <p className="ml-4">${(item.price * (item.quantity || 1)).toFixed(2)}</p>
                  </div>
                  <p className="mt-1 text-sm text-zinc-500 line-clamp-1">{item.description}</p>
                  <div className="flex items-center justify-between mt-auto">
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => updateCartItemQuantity(item.id, (item.quantity || 1) - 1)}
                        disabled={(item.quantity || 1) <= 1}
                      >
                        <Minus className="h-3 w-3" />
                        <span className="sr-only">Decrease quantity</span>
                      </Button>
                      <span className="w-8 text-center">{item.quantity || 1}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => updateCartItemQuantity(item.id, (item.quantity || 1) + 1)}
                        disabled={(item.quantity || 1) >= (item.inventory || 99)}
                      >
                        <Plus className="h-3 w-3" />
                        <span className="sr-only">Increase quantity</span>
                      </Button>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => removeFromCart(item.id)} className="text-zinc-500">
                      <Trash2 className="h-4 w-4" />
                      <span className="sr-only">Remove</span>
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6">
            <Link href="/products">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Continue Shopping
              </Button>
            </Link>
          </div>
        </div>
        <div className="lg:w-1/3">
          <div className="rounded-lg border bg-card p-6">
            <h2 className="text-lg font-semibold">Order Summary</h2>
            <div className="mt-6 space-y-4">
              <div className="flex justify-between">
                <p className="text-zinc-500">Subtotal</p>
                <p className="font-medium">${subtotal.toFixed(2)}</p>
              </div>
              <div className="flex justify-between">
                <p className="text-zinc-500">Shipping</p>
                <p className="font-medium">{shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`}</p>
              </div>
              <div className="flex items-center gap-2">
                <Input placeholder="Promo code" value={promoCode} onChange={(e) => setPromoCode(e.target.value)} />
                <Button variant="outline" onClick={handleApplyPromo} disabled={!promoCode || isApplyingPromo}>
                  {isApplyingPromo ? "Applying..." : "Apply"}
                </Button>
              </div>
              <Separator />
              <div className="flex justify-between">
                <p className="font-semibold">Total</p>
                <p className="font-semibold">${total.toFixed(2)}</p>
              </div>
              <Button className="w-full" size="lg" onClick={handleCheckout}>
                Checkout
              </Button>
              <p className="text-center text-xs text-zinc-500">Taxes calculated at checkout</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
