import Link from "next/link"
import { ShoppingCart } from "lucide-react"

import { Button } from "@/components/ui/button"

// Mock data for collections
const collections = {
  heritage: {
    id: "heritage",
    name: "Heritage Line",
    description: "Timeless designs inspired by our archives",
    products: [
      {
        id: "2",
        name: "Heritage Tweed Jacket",
        price: 499.99,
        image: "/placeholder.svg?height=400&width=300",
        description: "Classic tweed jacket with leather elbow patches, crafted using traditional methods.",
        category: "jackets",
        inventory: 12,
        collections: ["heritage", "signature"],
      },
      {
        id: "4",
        name: "Bespoke Oxford Shirt",
        price: 249.99,
        image: "/placeholder.svg?height=400&width=300",
        description: "Expertly crafted from Egyptian cotton with mother-of-pearl buttons.",
        category: "shirts",
        inventory: 20,
        collections: ["heritage", "essentials"],
      },
      {
        id: "5",
        name: "Merino Wool Waistcoat",
        price: 349.99,
        image: "/placeholder.svg?height=400&width=300",
        description: "Traditional waistcoat made from the finest merino wool with adjustable back strap.",
        category: "waistcoats",
        inventory: 15,
        collections: ["heritage", "formal"],
      },
    ],
  },
  signature: {
    id: "signature",
    name: "Signature Collection",
    description: "Our distinguished seasonal offerings",
    products: [
      {
        id: "1",
        name: "Handcrafted Wool Suit",
        price: 899.99,
        image: "/placeholder.svg?height=400&width=300",
        description: "A timeless three-piece suit meticulously tailored from premium Italian wool.",
        category: "suits",
        inventory: 15,
        collections: ["signature", "formal"],
      },
      {
        id: "2",
        name: "Heritage Tweed Jacket",
        price: 499.99,
        image: "/placeholder.svg?height=400&width=300",
        description: "Classic tweed jacket with leather elbow patches, crafted using traditional methods.",
        category: "jackets",
        inventory: 12,
        collections: ["heritage", "signature"],
      },
      {
        id: "6",
        name: "Cashmere Overcoat",
        price: 799.99,
        image: "/placeholder.svg?height=400&width=300",
        description: "Luxurious cashmere overcoat with traditional tailoring and satin lining.",
        category: "outerwear",
        inventory: 8,
        collections: ["signature", "outerwear"],
      },
    ],
  },
  formal: {
    id: "formal",
    name: "Formal Attire",
    description: "Sophisticated styles for special occasions",
    products: [
      {
        id: "1",
        name: "Handcrafted Wool Suit",
        price: 899.99,
        image: "/placeholder.svg?height=400&width=300",
        description: "A timeless three-piece suit meticulously tailored from premium Italian wool.",
        category: "suits",
        inventory: 15,
        collections: ["signature", "formal"],
      },
      {
        id: "3",
        name: "Silk Paisley Tie",
        price: 129.99,
        image: "/placeholder.svg?height=400&width=300",
        description: "Hand-rolled silk tie featuring our signature paisley pattern.",
        category: "accessories",
        inventory: 30,
        collections: ["accessories", "formal"],
      },
      {
        id: "7",
        name: "Formal Dress Shirt",
        price: 189.99,
        image: "/placeholder.svg?height=400&width=300",
        description: "Crisp white dress shirt with French cuffs and a classic spread collar.",
        category: "shirts",
        inventory: 25,
        collections: ["formal", "essentials"],
      },
    ],
  },
}

export default function CollectionPage({ params }: { params: { collectionId: string } }) {
  const collectionId = params.collectionId
  const collection = collections[collectionId as keyof typeof collections]

  if (!collection) {
    return (
      <div className="container px-4 py-12 md:px-6 md:py-16 lg:py-24">
        <h1 className="text-3xl font-bold text-[#2c2417]">Collection not found</h1>
        <p className="mt-4 text-[#5c4d3c]">The collection you're looking for doesn't exist.</p>
        <Link href="/collections">
          <Button className="mt-6 bg-[#2c2417] hover:bg-[#3d3224]">View all collections</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="container px-4 py-12 md:px-6 md:py-16 lg:py-24">
      <div className="flex flex-col items-start gap-4 md:gap-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight md:text-4xl lg:text-5xl text-[#2c2417]">
            {collection.name}
          </h1>
          <p className="mt-4 text-lg text-[#5c4d3c]">{collection.description}</p>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 w-full mt-8">
          {collection.products.map((product) => (
            <div
              key={product.id}
              className="group relative overflow-hidden rounded-md border border-[#e5ded3] bg-white"
            >
              <Link href={`/products/${product.id}`} className="block overflow-hidden">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="h-[300px] w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </Link>
              <div className="p-4">
                <Link href={`/products/${product.id}`}>
                  <h3 className="font-medium text-[#2c2417]">{product.name}</h3>
                </Link>
                <p className="mt-1 text-sm text-[#5c4d3c] line-clamp-2">{product.description}</p>
                <div className="mt-2 flex items-center justify-between">
                  <p className="font-serif text-[#2c2417]">${product.price.toFixed(2)}</p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 gap-1 border-[#2c2417] text-[#2c2417] hover:bg-[#2c2417] hover:text-white"
                  >
                    <ShoppingCart className="h-4 w-4" />
                    Add
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
