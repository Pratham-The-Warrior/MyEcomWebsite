import Link from "next/link"
import { ArrowRight } from "lucide-react"

// Mock data for all collections
const allCollections = [
  {
    id: "heritage",
    name: "Heritage Line",
    image: "/placeholder.svg?height=600&width=400",
    description: "Timeless designs inspired by our archives",
    productCount: 18,
  },
  {
    id: "signature",
    name: "Signature Collection",
    image: "/placeholder.svg?height=600&width=400",
    description: "Our distinguished seasonal offerings",
    productCount: 24,
  },
  {
    id: "formal",
    name: "Formal Attire",
    image: "/placeholder.svg?height=600&width=400",
    description: "Sophisticated styles for special occasions",
    productCount: 16,
  },
  {
    id: "bespoke",
    name: "Bespoke Tailoring",
    image: "/placeholder.svg?height=600&width=400",
    description: "Personalized garments crafted to perfection",
    productCount: 12,
  },
  {
    id: "accessories",
    name: "Fine Accessories",
    image: "/placeholder.svg?height=600&width=400",
    description: "Exquisite details to complete your ensemble",
    productCount: 20,
  },
  {
    id: "essentials",
    name: "Gentleman's Essentials",
    image: "/placeholder.svg?height=600&width=400",
    description: "Foundational pieces for the refined wardrobe",
    productCount: 15,
  },
]

export default function CollectionsPage() {
  return (
    <div className="container px-4 py-12 md:px-6 md:py-16 lg:py-24">
      <div className="flex flex-col items-start gap-4 md:gap-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight md:text-4xl lg:text-5xl text-[#2c2417]">Collections</h1>
          <p className="mt-4 text-lg text-[#5c4d3c]">Browse our curated collections of traditional menswear.</p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 w-full mt-8">
          {allCollections.map((collection) => (
            <Link
              key={collection.id}
              href={`/collections/${collection.id}`}
              className="group flex flex-col overflow-hidden rounded-md border border-[#e5ded3] bg-white transition-all hover:shadow-md"
            >
              <div className="aspect-[3/2] overflow-hidden">
                <img
                  src={collection.image || "/placeholder.svg"}
                  alt={collection.name}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </div>
              <div className="flex flex-col space-y-1.5 p-6">
                <h3 className="text-xl font-serif text-[#2c2417]">{collection.name}</h3>
                <p className="text-sm text-[#5c4d3c]">{collection.description}</p>
                <p className="mt-2 text-sm font-medium text-[#2c2417]">{collection.productCount} products</p>
                <div className="mt-4 flex items-center text-sm font-medium text-[#8b5a2b]">
                  View Collection
                  <ArrowRight className="ml-1 h-4 w-4" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
