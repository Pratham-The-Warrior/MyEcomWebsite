import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import FeaturedProducts from "@/components/featured-products"
import CollectionsShowcase from "@/components/collections-showcase"
import NewsletterSignup from "@/components/newsletter-signup"
import Testimonials from "@/components/testimonials"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-[#f8f5f0]">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-[#2c2417]">
                  Timeless Elegance for the Modern Gentleman
                </h1>
                <p className="max-w-[600px] text-[#5c4d3c] md:text-xl">
                  Discover our heritage collection of handcrafted traditional menswear, where craftsmanship meets
                  timeless style.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/collections">
                  <Button size="lg" className="gap-1.5 bg-[#2c2417] hover:bg-[#3d3224]">
                    Explore Collection
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/collections/heritage">
                  <Button size="lg" variant="outline" className="border-[#2c2417] text-[#2c2417]">
                    Heritage Line
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex justify-center">
              <div className="relative w-full max-w-[500px] aspect-square overflow-hidden rounded-xl">
                <img
                  alt="Traditional men's tailored suit"
                  className="object-cover"
                  src="/placeholder.svg?height=600&width=600"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Heritage Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-[#2c2417] text-[#f8f5f0]">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Heritage</h2>
              <p className="max-w-[900px] text-[#d3c7b8] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Since 1897, Traditionals has been crafting exceptional menswear with meticulous attention to detail and
                the finest materials.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
              <div className="flex flex-col items-center space-y-2">
                <div className="text-4xl font-serif">125+</div>
                <h3 className="text-xl font-medium">Years of Excellence</h3>
                <p className="text-[#d3c7b8] text-center">
                  A legacy of quality and craftsmanship passed through generations
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <div className="text-4xl font-serif">100%</div>
                <h3 className="text-xl font-medium">Handcrafted</h3>
                <p className="text-[#d3c7b8] text-center">Every garment meticulously crafted by master tailors</p>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <div className="text-4xl font-serif">12</div>
                <h3 className="text-xl font-medium">Artisan Workshops</h3>
                <p className="text-[#d3c7b8] text-center">Supporting traditional craftsmanship across the country</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Collections */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-[#f8f5f0]">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-[#2c2417]">
                Curated Collections
              </h2>
              <p className="max-w-[900px] text-[#5c4d3c] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Explore our timeless collections, each telling a story of heritage and craftsmanship.
              </p>
            </div>
          </div>
          <CollectionsShowcase />
        </div>
      </section>

      {/* Featured Products */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-[#2c2417]">
                Signature Pieces
              </h2>
              <p className="max-w-[900px] text-[#5c4d3c] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Our most distinguished garments, crafted with exceptional materials and timeless design.
              </p>
            </div>
          </div>
          <FeaturedProducts />
          <div className="flex justify-center mt-10">
            <Link href="/products">
              <Button size="lg" variant="outline" className="gap-1.5 border-[#2c2417] text-[#2c2417]">
                View All Products
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <Testimonials />

      {/* Newsletter Signup */}
      <NewsletterSignup />
    </div>
  )
}
