import Link from "next/link"
import { ChevronRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { getProductById } from "@/lib/db-service"
import ProductDetail from "@/components/product-detail"

export default async function ProductPage({ params }: { params: { productId: string } }) {
  const product = await getProductById(params.productId)

  if (!product) {
    return (
      <div className="container px-4 py-12 md:px-6 md:py-16 lg:py-24">
        <h1 className="text-3xl font-bold text-[#2c2417]">Product not found</h1>
        <p className="mt-4 text-[#5c4d3c]">The product you're looking for doesn't exist.</p>
        <Link href="/products">
          <Button className="mt-6 bg-[#2c2417] hover:bg-[#3d3224]">View all products</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="container px-4 py-12 md:px-6 md:py-16 lg:py-24">
      {/* Breadcrumbs */}
      <div className="mb-6 flex items-center text-sm text-[#5c4d3c]">
        <Link href="/" className="hover:text-[#2c2417]">
          Home
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <Link href="/products" className="hover:text-[#2c2417]">
          Products
        </Link>
        <ChevronRight className="mx-1 h-4 w-4" />
        <span className="text-[#2c2417]">{product.name}</span>
      </div>

      <ProductDetail product={product} />
    </div>
  )
}
