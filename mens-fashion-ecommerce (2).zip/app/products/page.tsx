import Link from "next/link"
import { ShoppingCart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { getAllProducts } from "@/lib/db-service"

export default async function ProductsPage() {
  const products = await getAllProducts()

  return (
    <div className="container px-4 py-12 md:px-6 md:py-16 lg:py-24">
      <div className="flex flex-col items-start gap-4 md:gap-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight md:text-4xl lg:text-5xl text-[#2c2417]">All Products</h1>
          <p className="mt-4 text-lg text-[#5c4d3c]">Browse our complete collection of traditional menswear.</p>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 w-full mt-8">
          {products.map((product) => (
            <div
              key={product.id}
              className="group relative overflow-hidden rounded-md border border-[#e5ded3] bg-white"
            >
              <Link href={`/products/${product.id}`} className="block overflow-hidden">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="h-[300px] w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </Link>
              <div className="p-4">
                <Link href={`/products/${product.id}`}>
                  <h3 className="font-medium text-[#2c2417]">{product.name}</h3>
                </Link>
                <p className="mt-1 text-sm text-[#5c4d3c] line-clamp-2">{product.description}</p>
                <div className="mt-2 flex items-center justify-between">
                  <p className="font-serif text-[#2c2417]">${product.price.toFixed(2)}</p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 gap-1 border-[#2c2417] text-[#2c2417] hover:bg-[#2c2417] hover:text-white"
                  >
                    <ShoppingCart className="h-4 w-4" />
                    Add
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
