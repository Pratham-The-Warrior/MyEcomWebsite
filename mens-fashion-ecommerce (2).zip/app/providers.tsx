"use client"

import type { ReactNode } from "react"
import { CartProvider } from "@/lib/cart-context"
import { InventoryProvider } from "@/lib/inventory-context"

export function Providers({ children }: { children: ReactNode }) {
  return (
    <CartProvider>
      <InventoryProvider>{children}</InventoryProvider>
    </CartProvider>
  )
}
