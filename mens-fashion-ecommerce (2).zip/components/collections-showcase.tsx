import Link from "next/link"

// Mock data for collections
const collections = [
  {
    id: "heritage",
    name: "Heritage Line",
    image: "/placeholder.svg?height=600&width=400",
    description: "Timeless designs inspired by our archives",
  },
  {
    id: "signature",
    name: "Signature Collection",
    image: "/placeholder.svg?height=600&width=400",
    description: "Our distinguished seasonal offerings",
  },
  {
    id: "bespoke",
    name: "Bespoke Tailoring",
    image: "/placeholder.svg?height=600&width=400",
    description: "Personalized garments crafted to perfection",
  },
]

export default function CollectionsShowcase() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
      {collections.map((collection) => (
        <Link
          key={collection.id}
          href={`/collections/${collection.id}`}
          className="group relative overflow-hidden rounded-md"
        >
          <div className="aspect-[3/4] overflow-hidden">
            <img
              src={collection.image || "/placeholder.svg"}
              alt={collection.name}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6 text-white">
            <h3 className="text-xl font-serif">{collection.name}</h3>
            <p className="text-sm text-white/90 mt-1">{collection.description}</p>
          </div>
        </Link>
      ))}
    </div>
  )
}
