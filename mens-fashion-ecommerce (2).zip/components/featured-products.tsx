"use client"
import Link from "next/link"
import { ShoppingCart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { useCart } from "@/lib/cart-context"
import type { Product } from "@/lib/types"

// Mock data for featured products
const featuredProducts: Product[] = [
  {
    id: "1",
    name: "Handcrafted Wool Suit",
    price: 899.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "A timeless three-piece suit meticulously tailored from premium Italian wool.",
    category: "suits",
    inventory: 15,
    collections: ["signature", "formal"],
  },
  {
    id: "2",
    name: "Heritage Tweed Jacket",
    price: 499.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Classic tweed jacket with leather elbow patches, crafted using traditional methods.",
    category: "jackets",
    inventory: 12,
    collections: ["heritage", "signature"],
  },
  {
    id: "3",
    name: "Silk Paisley Tie",
    price: 129.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Hand-rolled silk tie featuring our signature paisley pattern.",
    category: "accessories",
    inventory: 30,
    collections: ["accessories", "formal"],
  },
  {
    id: "4",
    name: "Bespoke Oxford Shirt",
    price: 249.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Expertly crafted from Egyptian cotton with mother-of-pearl buttons.",
    category: "shirts",
    inventory: 20,
    collections: ["heritage", "essentials"],
  },
]

export default function FeaturedProducts() {
  const { addToCart } = useCart()

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
      {featuredProducts.map((product) => (
        <div key={product.id} className="group relative overflow-hidden rounded-md border border-[#e5ded3] bg-white">
          <Link href={`/products/${product.id}`} className="block overflow-hidden">
            <img
              src={product.image || "/placeholder.svg"}
              alt={product.name}
              className="h-[300px] w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          </Link>
          <div className="p-4">
            <Link href={`/products/${product.id}`}>
              <h3 className="font-medium text-[#2c2417]">{product.name}</h3>
            </Link>
            <p className="mt-1 text-sm text-[#5c4d3c] line-clamp-2">{product.description}</p>
            <div className="mt-2 flex items-center justify-between">
              <p className="font-serif text-[#2c2417]">${product.price.toFixed(2)}</p>
              <Button
                size="sm"
                variant="outline"
                className="h-8 gap-1 border-[#2c2417] text-[#2c2417] hover:bg-[#2c2417] hover:text-white"
                onClick={() => addToCart(product)}
              >
                <ShoppingCart className="h-4 w-4" />
                Add
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
