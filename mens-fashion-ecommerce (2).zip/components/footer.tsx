import Link from "next/link"
import { Facebook, Instagram, Twitter } from "lucide-react"

export default function Footer() {
  return (
    <footer className="w-full border-t bg-[#2c2417] text-[#f8f5f0]">
      <div className="container px-4 md:px-6 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-lg font-serif">TRADITIONALS</h3>
            <p className="text-sm text-[#d3c7b8]">
              Crafting exceptional traditional menswear since 1897. Quality fabrics, timeless designs, impeccable
              craftsmanship.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-[#d3c7b8] hover:text-white">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-[#d3c7b8] hover:text-white">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-[#d3c7b8] hover:text-white">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-sm font-serif">Collections</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/collections/heritage" className="text-[#d3c7b8] hover:text-white">
                  Heritage Line
                </Link>
              </li>
              <li>
                <Link href="/collections/signature" className="text-[#d3c7b8] hover:text-white">
                  Signature Collection
                </Link>
              </li>
              <li>
                <Link href="/collections/formal" className="text-[#d3c7b8] hover:text-white">
                  Formal Attire
                </Link>
              </li>
              <li>
                <Link href="/collections/bespoke" className="text-[#d3c7b8] hover:text-white">
                  Bespoke Tailoring
                </Link>
              </li>
              <li>
                <Link href="/collections/accessories" className="text-[#d3c7b8] hover:text-white">
                  Fine Accessories
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-sm font-serif">Our Story</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about" className="text-[#d3c7b8] hover:text-white">
                  Our Heritage
                </Link>
              </li>
              <li>
                <Link href="/craftsmanship" className="text-[#d3c7b8] hover:text-white">
                  Craftsmanship
                </Link>
              </li>
              <li>
                <Link href="/stores" className="text-[#d3c7b8] hover:text-white">
                  Atelier Locations
                </Link>
              </li>
              <li>
                <Link href="/sustainability" className="text-[#d3c7b8] hover:text-white">
                  Ethical Practices
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-sm font-serif">Client Services</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/contact" className="text-[#d3c7b8] hover:text-white">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/shipping" className="text-[#d3c7b8] hover:text-white">
                  Shipping & Returns
                </Link>
              </li>
              <li>
                <Link href="/care" className="text-[#d3c7b8] hover:text-white">
                  Garment Care
                </Link>
              </li>
              <li>
                <Link href="/size-guide" className="text-[#d3c7b8] hover:text-white">
                  Size Guide
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-[#5c4d3c] pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-xs text-[#d3c7b8]">© 2024 Traditionals. All rights reserved. Est. 1897</p>
          <div className="flex gap-4 mt-4 md:mt-0">
            <Link href="/privacy" className="text-xs text-[#d3c7b8] hover:text-white">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-xs text-[#d3c7b8] hover:text-white">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
