"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, Search, ShoppingCart, User, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useCart } from "@/lib/cart-context"

export default function Header() {
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const { cartItems } = useCart()
  const cartItemCount = cartItems.length

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white">
      <div className="container flex h-20 items-center px-4 md:px-6">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden text-[#2c2417]">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[300px] sm:w-[400px] bg-[#f8f5f0]">
            <nav className="flex flex-col gap-4 mt-8">
              <Link href="/" className="text-lg font-serif text-[#2c2417]">
                Home
              </Link>
              <Link href="/collections" className="text-lg font-serif text-[#2c2417]">
                Collections
              </Link>
              <Link href="/products" className="text-lg font-serif text-[#2c2417]">
                All Products
              </Link>
              <Link href="/about" className="text-lg font-serif text-[#2c2417]">
                Our Heritage
              </Link>
              <Link href="/contact" className="text-lg font-serif text-[#2c2417]">
                Contact
              </Link>
              {/* Admin link */}
              <Link href="/admin" className="text-lg font-serif text-[#5c4d3c] mt-4">
                Admin Dashboard
              </Link>
            </nav>
          </SheetContent>
        </Sheet>
        <Link href="/" className="mr-6 flex items-center space-x-2">
          <span className="font-serif text-2xl text-[#2c2417]">TRADITIONALS</span>
        </Link>
        <nav className="hidden md:flex gap-8 ml-6">
          <Link
            href="/"
            className="text-sm font-medium text-[#2c2417] hover:text-[#5c4d3c] hover:underline underline-offset-4"
          >
            Home
          </Link>
          <Link
            href="/collections"
            className="text-sm font-medium text-[#2c2417] hover:text-[#5c4d3c] hover:underline underline-offset-4"
          >
            Collections
          </Link>
          <Link
            href="/products"
            className="text-sm font-medium text-[#2c2417] hover:text-[#5c4d3c] hover:underline underline-offset-4"
          >
            All Products
          </Link>
          <Link
            href="/about"
            className="text-sm font-medium text-[#2c2417] hover:text-[#5c4d3c] hover:underline underline-offset-4"
          >
            Our Heritage
          </Link>
          <Link
            href="/contact"
            className="text-sm font-medium text-[#2c2417] hover:text-[#5c4d3c] hover:underline underline-offset-4"
          >
            Contact
          </Link>
        </nav>
        <div className="ml-auto flex items-center gap-2">
          {isSearchOpen ? (
            <div className="flex items-center">
              <Input type="search" placeholder="Search products..." className="w-[200px] md:w-[300px] mr-2" autoFocus />
              <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(false)} className="text-[#2c2417]">
                <X className="h-5 w-5" />
                <span className="sr-only">Close search</span>
              </Button>
            </div>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(true)} className="text-[#2c2417]">
              <Search className="h-5 w-5" />
              <span className="sr-only">Search</span>
            </Button>
          )}
          <Link href="/account">
            <Button variant="ghost" size="icon" className="text-[#2c2417]">
              <User className="h-5 w-5" />
              <span className="sr-only">Account</span>
            </Button>
          </Link>
          <Link href="/cart">
            <Button variant="ghost" size="icon" className="relative text-[#2c2417]">
              <ShoppingCart className="h-5 w-5" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-[#8b5a2b] text-xs text-white flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
              <span className="sr-only">Cart</span>
            </Button>
          </Link>
          <Link href="/admin" className="hidden md:block">
            <Button variant="outline" size="sm" className="border-[#2c2417] text-[#2c2417]">
              Admin
            </Button>
          </Link>
        </div>
      </div>
    </header>
  )
}
