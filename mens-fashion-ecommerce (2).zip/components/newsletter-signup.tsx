"use client"

import type React from "react"

import { useState } from "react"
import { Send } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"

export default function NewsletterSignup() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      setEmail("")
      toast({
        title: "Thank you!",
        description: "You've been subscribed to our newsletter.",
      })
    }, 1000)
  }

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 border-t bg-[#f8f5f0]">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-[#2c2417]">
              Join Our Legacy
            </h2>
            <p className="max-w-[600px] text-[#5c4d3c] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Subscribe to receive updates on new collections, exclusive events, and style insights.
            </p>
          </div>
          <div className="w-full max-w-md space-y-2">
            <form className="flex space-x-2" onSubmit={handleSubmit}>
              <Input
                className="max-w-lg flex-1 border-[#d3c7b8] bg-white"
                placeholder="Enter your email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Button type="submit" disabled={isLoading} className="bg-[#2c2417] hover:bg-[#3d3224]">
                {isLoading ? (
                  "Subscribing..."
                ) : (
                  <>
                    Subscribe
                    <Send className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </form>
            <p className="text-xs text-[#5c4d3c]">By subscribing, you agree to our terms and privacy policy.</p>
          </div>
        </div>
      </div>
    </section>
  )
}
