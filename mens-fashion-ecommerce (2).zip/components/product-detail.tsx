"use client"

import { useState } from "react"
import { Minus, Plus, ShoppingCart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { useCart } from "@/lib/cart-context"
import type { Product } from "@/lib/types"

export default function ProductDetail({ product }: { product: Product }) {
  const [quantity, setQuantity] = useState(1)
  const { addToCart } = useCart()

  const handleAddToCart = () => {
    addToCart({ ...product, quantity })
  }

  return (
    <div className="grid gap-8 md:grid-cols-2">
      {/* Product Image */}
      <div className="overflow-hidden rounded-md border border-[#e5ded3] bg-white">
        <img src={product.image || "/placeholder.svg"} alt={product.name} className="h-full w-full object-cover" />
      </div>

      {/* Product Details */}
      <div className="flex flex-col space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-[#2c2417]">{product.name}</h1>
          <p className="mt-2 text-2xl font-serif text-[#2c2417]">${product.price.toFixed(2)}</p>
        </div>

        <div className="prose max-w-none text-[#5c4d3c]">
          <p>{product.description}</p>
        </div>

        <div className="space-y-4">
          <div>
            <p className="text-sm font-medium text-[#2c2417]">Quantity</p>
            <div className="mt-2 flex items-center space-x-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
                className="border-[#2c2417] text-[#2c2417]"
              >
                <Minus className="h-4 w-4" />
                <span className="sr-only">Decrease quantity</span>
              </Button>
              <span className="w-8 text-center">{quantity}</span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.min(product.inventory, quantity + 1))}
                disabled={quantity >= product.inventory}
                className="border-[#2c2417] text-[#2c2417]"
              >
                <Plus className="h-4 w-4" />
                <span className="sr-only">Increase quantity</span>
              </Button>
            </div>
          </div>

          <div className="flex items-center text-sm">
            <span className={product.inventory > 0 ? "text-green-600" : "text-red-600"}>
              {product.inventory > 0 ? `In Stock (${product.inventory} available)` : "Out of Stock"}
            </span>
          </div>

          <Button
            size="lg"
            className="w-full gap-2 bg-[#2c2417] hover:bg-[#3d3224]"
            onClick={handleAddToCart}
            disabled={product.inventory === 0}
          >
            <ShoppingCart className="h-5 w-5" />
            Add to Cart
          </Button>
        </div>

        <div className="border-t border-[#e5ded3] pt-6">
          <h3 className="text-lg font-medium text-[#2c2417]">Product Details</h3>
          <ul className="mt-4 space-y-2 text-sm">
            <li className="flex justify-between">
              <span className="text-[#5c4d3c]">Category</span>
              <span className="capitalize text-[#2c2417]">{product.category}</span>
            </li>
            <li className="flex justify-between">
              <span className="text-[#5c4d3c]">Collections</span>
              <span className="capitalize text-[#2c2417]">{product.collections.join(", ")}</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}
