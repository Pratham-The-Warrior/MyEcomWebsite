import { Quote } from "lucide-react"

export default function Testimonials() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-[#f8f5f0]">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-[#2c2417]">
              Distinguished Clientele
            </h2>
            <p className="max-w-[900px] text-[#5c4d3c] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              What our esteemed clients say about their Traditionals experience.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          <div className="flex flex-col p-6 bg-white rounded-md border border-[#e5ded3]">
            <Quote className="h-8 w-8 text-[#8b5a2b] mb-4" />
            <p className="text-[#2c2417] italic mb-6">
              "The craftsmanship of my bespoke suit is unparalleled. Every detail speaks to the heritage and expertise
              of Traditionals. It's not just clothing; it's an investment in timeless elegance."
            </p>
            <div className="mt-auto">
              <p className="font-medium text-[#2c2417]">James Harrington</p>
              <p className="text-sm text-[#5c4d3c]">London, UK</p>
            </div>
          </div>
          <div className="flex flex-col p-6 bg-white rounded-md border border-[#e5ded3]">
            <Quote className="h-8 w-8 text-[#8b5a2b] mb-4" />
            <p className="text-[#2c2417] italic mb-6">
              "I've been a loyal customer for over 20 years. The quality and attention to detail in every garment is
              remarkable. Traditionals represents the pinnacle of traditional menswear."
            </p>
            <div className="mt-auto">
              <p className="font-medium text-[#2c2417]">Robert Montgomery</p>
              <p className="text-sm text-[#5c4d3c]">New York, USA</p>
            </div>
          </div>
          <div className="flex flex-col p-6 bg-white rounded-md border border-[#e5ded3]">
            <Quote className="h-8 w-8 text-[#8b5a2b] mb-4" />
            <p className="text-[#2c2417] italic mb-6">
              "The heritage tweed jacket I purchased has become my most treasured garment. The materials, the fit, and
              the service were all exceptional. Traditionals truly honors the art of traditional tailoring."
            </p>
            <div className="mt-auto">
              <p className="font-medium text-[#2c2417]">William Blackwood</p>
              <p className="text-sm text-[#5c4d3c]">Edinburgh, Scotland</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
