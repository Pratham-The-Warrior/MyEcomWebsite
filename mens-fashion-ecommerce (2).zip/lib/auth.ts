"use server"

import { cookies } from "next/headers"

// In a real application, you would use a proper authentication system
// This is a simplified version for demonstration purposes
const ADMIN_USERNAME = "admin"
const ADMIN_PASSWORD = "password123" // In production, use hashed passwords

export async function login(username: string, password: string) {
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    // Set a cookie to indicate the user is logged in
    cookies().set("admin-auth", "true", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24, // 1 day
      path: "/",
    })
    return { success: true }
  }
  return { success: false, error: "Invalid credentials" }
}

export async function logout() {
  cookies().delete("admin-auth")
  return { success: true }
}

export async function isAuthenticated() {
  const authCookie = cookies().get("admin-auth")
  return authCookie?.value === "true"
}
