"use server"

import { cookies } from "next/headers"
import { isAuthenticated } from "./auth"
import type { Product } from "./types"

// In a real application, you would use a database like MongoDB, PostgreSQL, etc.
// For simplicity, we'll use a JSON file stored in cookies as our "database"

// Helper function to get products from cookie
async function getProductsFromStorage(): Promise<Product[]> {
  try {
    const productsCookie = cookies().get("products-data")
    if (!productsCookie) {
      // Initialize with sample data if no products exist
      return initialProducts
    }
    return JSON.parse(productsCookie.value) as Product[]
  } catch (error) {
    console.error("Error getting products:", error)
    return initialProducts
  }
}

// Helper function to save products to cookie
async function saveProductsToStorage(products: Product[]) {
  try {
    cookies().set("products-data", JSON.stringify(products), {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      path: "/",
    })
  } catch (error) {
    console.error("Error saving products:", error)
  }
}

// Initial sample products
const initialProducts: Product[] = [
  {
    id: "1",
    name: "Handcrafted Wool Suit",
    price: 899.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "A timeless three-piece suit meticulously tailored from premium Italian wool.",
    category: "suits",
    inventory: 15,
    collections: ["signature", "formal"],
  },
  {
    id: "2",
    name: "Heritage Tweed Jacket",
    price: 499.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Classic tweed jacket with leather elbow patches, crafted using traditional methods.",
    category: "jackets",
    inventory: 12,
    collections: ["heritage", "signature"],
  },
  {
    id: "3",
    name: "Silk Paisley Tie",
    price: 129.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Hand-rolled silk tie featuring our signature paisley pattern.",
    category: "accessories",
    inventory: 30,
    collections: ["accessories", "formal"],
  },
  {
    id: "4",
    name: "Bespoke Oxford Shirt",
    price: 249.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Expertly crafted from Egyptian cotton with mother-of-pearl buttons.",
    category: "shirts",
    inventory: 20,
    collections: ["heritage", "essentials"],
  },
]

// CRUD operations
export async function getAllProducts(): Promise<Product[]> {
  return getProductsFromStorage()
}

export async function getProductById(id: string): Promise<Product | null> {
  const products = await getProductsFromStorage()
  return products.find((product) => product.id === id) || null
}

export async function addProduct(
  product: Omit<Product, "id">,
): Promise<{ success: boolean; error?: string; product?: Product }> {
  const isAdmin = await isAuthenticated()
  if (!isAdmin) {
    return { success: false, error: "Unauthorized" }
  }

  try {
    const products = await getProductsFromStorage()
    const newProduct: Product = {
      ...product,
      id: Date.now().toString(), // Simple ID generation
    }

    await saveProductsToStorage([...products, newProduct])
    return { success: true, product: newProduct }
  } catch (error) {
    console.error("Error adding product:", error)
    return { success: false, error: "Failed to add product" }
  }
}

export async function updateProduct(product: Product): Promise<{ success: boolean; error?: string }> {
  const isAdmin = await isAuthenticated()
  if (!isAdmin) {
    return { success: false, error: "Unauthorized" }
  }

  try {
    const products = await getProductsFromStorage()
    const index = products.findIndex((p) => p.id === product.id)

    if (index === -1) {
      return { success: false, error: "Product not found" }
    }

    products[index] = product
    await saveProductsToStorage(products)
    return { success: true }
  } catch (error) {
    console.error("Error updating product:", error)
    return { success: false, error: "Failed to update product" }
  }
}

export async function deleteProduct(id: string): Promise<{ success: boolean; error?: string }> {
  const isAdmin = await isAuthenticated()
  if (!isAdmin) {
    return { success: false, error: "Unauthorized" }
  }

  try {
    const products = await getProductsFromStorage()
    const filteredProducts = products.filter((product) => product.id !== id)

    if (filteredProducts.length === products.length) {
      return { success: false, error: "Product not found" }
    }

    await saveProductsToStorage(filteredProducts)
    return { success: true }
  } catch (error) {
    console.error("Error deleting product:", error)
    return { success: false, error: "Failed to delete product" }
  }
}
