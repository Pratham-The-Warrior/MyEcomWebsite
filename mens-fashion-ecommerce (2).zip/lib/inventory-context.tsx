"use client"

import { createContext, useContext, useState, type ReactNode } from "react"
import type { Product } from "./types"

// Mock initial products data
const initialProducts: Product[] = [
  {
    id: "1",
    name: "Classic Oxford Shirt",
    price: 89.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "A timeless oxford shirt made from premium cotton.",
    category: "shirts",
    inventory: 25,
    collections: ["best-sellers", "essentials"],
  },
  {
    id: "2",
    name: "Slim Fit Chinos",
    price: 79.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Comfortable slim fit chinos perfect for any occasion.",
    category: "pants",
    inventory: 18,
    collections: ["best-sellers", "essentials"],
  },
  {
    id: "3",
    name: "Leather Belt",
    price: 49.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "Premium leather belt with a classic buckle.",
    category: "accessories",
    inventory: 30,
    collections: ["accessories", "essentials"],
  },
  {
    id: "4",
    name: "Wool Blazer",
    price: 199.99,
    image: "/placeholder.svg?height=400&width=300",
    description: "A sophisticated wool blazer for formal occasions.",
    category: "outerwear",
    inventory: 12,
    collections: ["new-arrivals", "formal"],
  },
]

interface InventoryContextType {
  products: Product[]
  addProduct: (product: Product) => void
  updateProduct: (product: Product) => void
  deleteProduct: (productId: string) => void
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined)

export function InventoryProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>(initialProducts)

  const addProduct = (product: Product) => {
    setProducts((prevProducts) => [...prevProducts, product])
  }

  const updateProduct = (updatedProduct: Product) => {
    setProducts((prevProducts) =>
      prevProducts.map((product) => (product.id === updatedProduct.id ? updatedProduct : product)),
    )
  }

  const deleteProduct = (productId: string) => {
    setProducts((prevProducts) => prevProducts.filter((product) => product.id !== productId))
  }

  return (
    <InventoryContext.Provider
      value={{
        products,
        addProduct,
        updateProduct,
        deleteProduct,
      }}
    >
      {children}
    </InventoryContext.Provider>
  )
}

export function useInventory() {
  const context = useContext(InventoryContext)
  if (context === undefined) {
    throw new Error("useInventory must be used within an InventoryProvider")
  }
  return context
}
